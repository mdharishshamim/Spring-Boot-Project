package com.agrigov.service;

import java.util.List;
import com.agrigov.dto.FarmerRequest; // Added
import com.agrigov.dto.FarmerResponse; // Added

public interface FarmerService {

	FarmerResponse registerFarmer(FarmerRequest farmerRequest);

	FarmerResponse updateFarmer(FarmerRequest farmerRequest, Long farmerId);

	void deleteFarmer(Long farmerId);

	FarmerResponse getFarmerById(Long farmerId);

	List<FarmerResponse> getAllFarmers();

	List<FarmerResponse> getFarmersByStatus(String status);
}
