package com.agrigov.service;

import java.util.List;

import com.agrigov.dto.SubsidyRequest;
import com.agrigov.dto.SubsidyResponse;

public interface SubsidyService {

    SubsidyResponse create(SubsidyRequest request);

    List<SubsidyResponse> getAll();

    SubsidyResponse getById(Long subsidyId);

    SubsidyResponse update(Long subsidyId, SubsidyRequest request);

    void delete(Long subsidyId);
}