package com.agrigov.service;

import com.agrigov.dto.AuditLogResponse;
import com.agrigov.model.AuditLog;
import com.agrigov.repository.AuditLogRepository;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.NoSuchElementException;
import java.util.stream.Collectors;

@Service
public class AuditLogServiceImpl implements AuditLogService {

    private static final Logger log = LoggerFactory.getLogger(AuditLogServiceImpl.class);

    private final AuditLogRepository repository;

    @Autowired
    public AuditLogServiceImpl(AuditLogRepository repository) {
        this.repository = repository;
    }

    @Override
    public AuditLogResponse get(Integer auditId) {
        log.debug("Fetching audit log with ID: {}", auditId);

        AuditLog entity = repository.findById(auditId)
                .orElseThrow(() -> {
                    log.error("Audit log not found with ID: {}", auditId);
                    return new NoSuchElementException("Audit log not found: " + auditId);
                });

        log.info("Audit log retrieved successfully: {}", auditId);
        return toResponse(entity);
    }

    @Override
    public List<AuditLogResponse> getAll() {
        log.debug("Fetching all audit logs");

        List<AuditLogResponse> list = repository.findAll()
                .stream()
                .map(this::toResponse)
                .collect(Collectors.toList());

        log.info("Total audit logs fetched: {}", list.size());
        return list;
    }

    private AuditLogResponse toResponse(AuditLog entity) {
        AuditLogResponse dto = new AuditLogResponse();
        dto.setAuditId(entity.getAuditId());
        dto.setUserId(entity.getUserId());
        dto.setAction(entity.getAction());
        dto.setResource(entity.getResource());
        dto.setTimestamp(entity.getTimestamp());
        return dto;
    }
}