package com.agrigov.service;

import java.util.List;
import org.springframework.web.multipart.MultipartFile;
import com.agrigov.dto.FarmerDocumentRequest;
import com.agrigov.dto.FarmerDocumentResponse;

public interface FarmerDocumentService {
    
    // Upload using MultipartFile
    FarmerDocumentResponse uploadDocument(Long farmerId, String docType, MultipartFile file);

    // Update existing document metadata only
    FarmerDocumentResponse updateDocument(Long documentId, FarmerDocumentRequest request);

    // Update document with optional file replacement
    FarmerDocumentResponse updateDocument(Long documentId, String docType, MultipartFile file);

    // Delete document (DB + file)
    void deleteDocument(Long documentId);

    // Fetch single document
    FarmerDocumentResponse getDocumentById(Long documentId);

    // Fetch documents by farmer
    List<FarmerDocumentResponse> getDocumentsByFarmer(Long farmerId);

    // Fetch documents by status
    List<FarmerDocumentResponse> getDocumentsByStatus(String status);
}