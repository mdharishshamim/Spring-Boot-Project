package com.agrigov.service;

import com.agrigov.dto.AuditLogResponse;

import java.util.List;

public interface AuditLogService {
    AuditLogResponse get(Integer AuditId);
    List<AuditLogResponse> getAll();
}