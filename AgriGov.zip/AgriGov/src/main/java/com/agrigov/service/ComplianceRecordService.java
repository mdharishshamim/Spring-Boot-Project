package com.agrigov.service;

import java.util.List;

import org.springframework.stereotype.Service;

import com.agrigov.dto.ComplianceRecordRequest;
import com.agrigov.dto.ComplianceRecordResponse;

@Service
public interface ComplianceRecordService {
	ComplianceRecordResponse create(ComplianceRecordRequest request);
    ComplianceRecordResponse update(Integer complianceId, ComplianceRecordRequest request);
    ComplianceRecordResponse get(Integer complianceId);
    List<ComplianceRecordResponse> getAll();
    ComplianceRecordResponse delete(Integer complianceId);
}