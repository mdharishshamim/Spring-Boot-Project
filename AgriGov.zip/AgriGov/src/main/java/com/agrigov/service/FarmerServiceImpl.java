package com.agrigov.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.agrigov.dto.FarmerDocumentResponse;
import com.agrigov.dto.FarmerRequest;
import com.agrigov.dto.FarmerResponse;
import com.agrigov.model.Farmer;
import com.agrigov.repository.FarmerRepository;

import lombok.extern.slf4j.Slf4j;

@Service
@Slf4j
public class FarmerServiceImpl implements FarmerService {

    @Autowired
    private FarmerRepository repository;

    @Override
    public FarmerResponse registerFarmer(FarmerRequest farmerRequest) {
        log.info("Registering farmer: {}", farmerRequest.getName());

        Farmer farmer = new Farmer();
        farmer.setName(farmerRequest.getName());
        farmer.setDob(farmerRequest.getDob());
        farmer.setGender(farmerRequest.getGender());
        farmer.setAddress(farmerRequest.getAddress());
        farmer.setContactInfo(farmerRequest.getContactInfo());
        farmer.setLandDetails(farmerRequest.getLandDetails());
        farmer.setStatus(farmerRequest.getStatus());

        Farmer saved = repository.save(farmer);
        log.debug("Farmer saved with ID: {}", saved.getFarmerId());

        return toResponse(saved);
    }

    @Override
    public FarmerResponse updateFarmer(FarmerRequest farmerRequest, Long farmerId) {
        log.info("Updating farmer with ID: {}", farmerId);
        return repository.findById(farmerId).map(existingFarmer -> {
            existingFarmer.setName(farmerRequest.getName());
            existingFarmer.setDob(farmerRequest.getDob());
            existingFarmer.setGender(farmerRequest.getGender());
            existingFarmer.setAddress(farmerRequest.getAddress());
            existingFarmer.setContactInfo(farmerRequest.getContactInfo());
            existingFarmer.setLandDetails(farmerRequest.getLandDetails());
            existingFarmer.setStatus(farmerRequest.getStatus());

            Farmer updated = repository.save(existingFarmer);
            log.debug("Farmer updated successfully with ID: {}", updated.getFarmerId());
            return toResponse(updated);
        }).orElseGet(() -> {
            log.error("Farmer with ID {} not found for update", farmerId);
            return null;
        });
    }

    @Override
    public void deleteFarmer(Long farmerId) {
        log.warn("Deleting farmer with ID: {}", farmerId);
        repository.deleteById(farmerId);
        log.info("Farmer with ID {} deleted successfully", farmerId);
    }

    @Override
    public FarmerResponse getFarmerById(Long farmerId) {
        log.debug("Fetching farmer by ID: {}", farmerId);
        return repository.findById(farmerId).map(farmer -> {
            log.info("Farmer found with ID: {}", farmerId);
            return toResponse(farmer);
        }).orElseGet(() -> {
            log.error("Farmer with ID {} not found", farmerId);
            return null;
        });
    }

    @Override
    public List<FarmerResponse> getAllFarmers() {
        log.debug("Fetching all farmers from database");
        List<FarmerResponse> farmers = repository.findAll().stream()
                .map(this::toResponse)
                .toList();
        log.info("Total farmers fetched: {}", farmers.size());
        return farmers;
    }

    @Override
    public List<FarmerResponse> getFarmersByStatus(String status) {
        log.info("Fetching farmers with status: {}", status);
        List<FarmerResponse> farmers = repository.findByStatus(status).stream()
                .map(this::toResponse)
                .toList();
        log.info("Total farmers fetched with status {}: {}", status, farmers.size());
        return farmers;
    }

    // Manual mapper: Farmer → FarmerResponse
    private FarmerResponse toResponse(Farmer farmer) {
        FarmerResponse response = new FarmerResponse();
        response.setFarmerId(farmer.getFarmerId());
        response.setName(farmer.getName());
        response.setDob(farmer.getDob());
        response.setGender(farmer.getGender());
        response.setAddress(farmer.getAddress());
        response.setContactInfo(farmer.getContactInfo());
        response.setLandDetails(farmer.getLandDetails());
        response.setStatus(farmer.getStatus());

        if (farmer.getDocuments() != null) {
            response.setDocuments(
                farmer.getDocuments().stream().map(doc -> {
                    FarmerDocumentResponse docRes = new FarmerDocumentResponse();
                    docRes.setDocumentId(doc.getDocumentId());
                    docRes.setFarmerId(doc.getFarmer().getFarmerId());
                    docRes.setDocType(doc.getDocType());
                    docRes.setFileUri(doc.getFileUri());
                    docRes.setUploadedDate(doc.getUploadedDate());
                    docRes.setVerificationStatus(doc.getVerificationStatus());
                    return docRes;
                }).toList()
            );
        }
        return response;
    }
}
