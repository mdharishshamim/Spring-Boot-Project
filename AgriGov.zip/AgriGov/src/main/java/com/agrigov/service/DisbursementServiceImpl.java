package com.agrigov.service;

import java.util.List;
import java.util.stream.Collectors;

import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.agrigov.dto.DisbursementRequest;
import com.agrigov.dto.DisbursementResponse;
import com.agrigov.model.Disbursement;
import com.agrigov.model.Subsidy;
import com.agrigov.model.User;
import com.agrigov.repository.DisbursementRepository;
import com.agrigov.repository.SubsidyRepository;
import com.agrigov.repository.UserRepository;

import jakarta.persistence.EntityNotFoundException;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;

@Service
@RequiredArgsConstructor
@Transactional
@Slf4j
public class DisbursementServiceImpl implements DisbursementService {

	private final DisbursementRepository disbursementRepository;
	private final SubsidyRepository subsidyRepository;
	private final UserRepository userRepository;

	@Override
	public DisbursementResponse create(DisbursementRequest request) {

		log.info("Creating Disbursement: subsidyId={}, officerId={}", request.getSubsidyId(), request.getOfficerId());

		Subsidy subsidy = subsidyRepository.findById(request.getSubsidyId()).orElseThrow(() -> {
			log.warn("Subsidy not found: {}", request.getSubsidyId());
			return new EntityNotFoundException("Subsidy not found: " + request.getSubsidyId());
		});

		if (!"APPROVED".equalsIgnoreCase(subsidy.getStatus())) {
			log.warn("Disbursement denied. Subsidy id={} status={}", subsidy.getSubsidyId(), subsidy.getStatus());
			throw new IllegalStateException("Disbursement allowed only for APPROVED subsidies");
		}

		User officer = userRepository.findById(request.getOfficerId()).orElseThrow(() -> {
			log.warn("Officer not found: {}", request.getOfficerId());
			return new EntityNotFoundException("Officer not found: " + request.getOfficerId());
		});

		Disbursement entity = new Disbursement();
		entity.setSubsidy(subsidy);
		entity.setOfficer(officer);
		entity.setDate(request.getDate());
		entity.setStatus(request.getStatus());

		entity = disbursementRepository.save(entity);

		log.info("Disbursement created successfully id={}", entity.getDisbursementId());

		return toResponse(entity);
	}

	@Override
	public DisbursementResponse getById(Long id) {
		log.info("Fetching Disbursement id={}", id);
		return toResponse(findEntity(id));
	}

	@Override
	public List<DisbursementResponse> getAll() {
		log.info("Fetching all Disbursements");
		return disbursementRepository.findAll().stream().map(this::toResponse).toList();
	}

	@Override
	public DisbursementResponse update(Long id, DisbursementRequest request) {

		log.info("Updating Disbursement id={}", id);

		Disbursement entity = findEntity(id);

		Subsidy subsidy = subsidyRepository.findById(request.getSubsidyId()).orElseThrow(() -> {
			log.warn("Subsidy not found: {}", request.getSubsidyId());
			return new EntityNotFoundException("Subsidy not found: " + request.getSubsidyId());
		});

		User officer = userRepository.findById(request.getOfficerId()).orElseThrow(() -> {
			log.warn("Officer not found: {}", request.getOfficerId());
			return new EntityNotFoundException("Officer not found: " + request.getOfficerId());
		});

		entity.setSubsidy(subsidy);
		entity.setOfficer(officer);
		entity.setDate(request.getDate());
		entity.setStatus(request.getStatus());

		log.info("Disbursement updated successfully id={}", id);

		return toResponse(entity);
	}

	@Override
	public void delete(Long id) {
		log.info("Deleting Disbursement id={}", id);

		if (!disbursementRepository.existsById(id)) {
			log.warn("Disbursement not found id={}", id);
			throw new EntityNotFoundException("Disbursement not found: " + id);
		}

		disbursementRepository.deleteById(id);
		log.info("Disbursement deleted successfully id={}", id);
	}

	private Disbursement findEntity(Long id) {
		return disbursementRepository.findById(id).orElseThrow(() -> {
			log.warn("Disbursement not found id={}", id);
			return new EntityNotFoundException("Disbursement not found: " + id);
		});
	}

	private DisbursementResponse toResponse(Disbursement d) {
		DisbursementResponse res = new DisbursementResponse();
		res.setDisbursementId(d.getDisbursementId());
		res.setSubsidyId(d.getSubsidy().getSubsidyId());
		res.setOfficerId(d.getOfficer().getUserId());
		res.setDate(d.getDate());
		res.setStatus(d.getStatus());
		return res;
	}
}