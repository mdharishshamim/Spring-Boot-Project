package com.agrigov.service;

import com.agrigov.dto.UserRequest;
import com.agrigov.dto.UserResponse;

import java.util.List;

public interface UserService {
    UserResponse create(UserRequest request);
    UserResponse update(Integer UserId, UserRequest request);
    UserResponse get(Integer UserId);
    void delete(Integer UserId);
    List<UserResponse> getAll();

}