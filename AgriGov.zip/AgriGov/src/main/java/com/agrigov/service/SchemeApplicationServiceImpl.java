package com.agrigov.service;

import java.util.List;
import java.util.stream.Collectors;

import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.agrigov.dto.SchemeApplicationRequest;
import com.agrigov.dto.SchemeApplicationResponse;
import com.agrigov.exception.SchemeApplicationNotFoundException;
//import com.agrigov.model.Farmer;
import com.agrigov.model.PolicyScheme;
import com.agrigov.model.SchemeApplication;
//import com.agrigov.repository.FarmerRepository;
import com.agrigov.repository.PolicySchemeRepository;
import com.agrigov.repository.SchemeApplicationRepository;

@Service
@Transactional
public class SchemeApplicationServiceImpl implements SchemeApplicationService {

    private final SchemeApplicationRepository schemeApplicationRepository;
    private final PolicySchemeRepository policySchemeRepository;
//    private final FarmerRepository farmerRepository;

    public SchemeApplicationServiceImpl(
            SchemeApplicationRepository schemeApplicationRepository,
            PolicySchemeRepository policySchemeRepository) {

        this.schemeApplicationRepository = schemeApplicationRepository;
        this.policySchemeRepository = policySchemeRepository;
//        this.farmerRepository = farmerRepository;
    }

    // ---------------- CREATE ----------------

    @Override
    public SchemeApplicationResponse create(SchemeApplicationRequest request) {

        SchemeApplication schemeApplication = new SchemeApplication();
        apply(schemeApplication, request);

        schemeApplication = schemeApplicationRepository.save(schemeApplication);
        return toResponse(schemeApplication);
    }

    // ---------------- GET ALL BY SCHEME ----------------

    @Override
    @Transactional(readOnly = true)
    public List<SchemeApplicationResponse> getAppliedBySchemeId(Long schemeID) {

        // validate scheme exists
        policySchemeRepository.findById(schemeID)
                .orElseThrow(() -> new SchemeApplicationNotFoundException(
                        "PolicyScheme not found for: " + schemeID));

        return schemeApplicationRepository
                .findByPolicyscheme_SchemeID(schemeID)
                .stream()
                .map(this::toResponse)
                .collect(Collectors.toList());
    }
    
 // ---------------- GET ALL APPLICATIONS ----------------

    @Override
    @Transactional(readOnly = true)
    public List<SchemeApplicationResponse> getAllApplications() {

        return schemeApplicationRepository
                .findAll()
                .stream()
                .map(this::toResponse)
                .collect(Collectors.toList());
    }

    // ---------------- GET BY ID ----------------

    @Override
    @Transactional(readOnly = true)
    public SchemeApplicationResponse getById(Long applicationID) {

        SchemeApplication schemeApplication =
                schemeApplicationRepository.findById(applicationID)
                        .orElseThrow(() ->
                                new SchemeApplicationNotFoundException(
                                        "Scheme application not found for: " + applicationID));

        return toResponse(schemeApplication);
    }

    // ---------------- DELETE ----------------

    @Override
    public void deleteappl(Long applicationID) {

        SchemeApplication schemeApplication =
                schemeApplicationRepository.findById(applicationID)
                        .orElseThrow(() ->
                                new SchemeApplicationNotFoundException(
                                        "Scheme application not found for: " + applicationID));

        schemeApplicationRepository.delete(schemeApplication);
    }

    // ---------------- UPDATE ----------------

    @Override
    public SchemeApplicationResponse update(Long applicationID,
                                            SchemeApplicationRequest request) {

        SchemeApplication schemeApplication =
                schemeApplicationRepository.findById(applicationID)
                        .orElseThrow(() ->
                                new SchemeApplicationNotFoundException(
                                        "Scheme application not found for: " + applicationID));

        apply(schemeApplication, request);
        schemeApplication = schemeApplicationRepository.save(schemeApplication);

        return toResponse(schemeApplication);
    }

    // ---------------- INTERNAL MAPPING ----------------

    private void apply(SchemeApplication entity, SchemeApplicationRequest dto) {

        PolicyScheme policyScheme =
                policySchemeRepository.findById(dto.getSchemeID())
                        .orElseThrow(() ->
                                new SchemeApplicationNotFoundException(
                                        "PolicyScheme not found for: " + dto.getSchemeID()));

//        Farmer farmer =
//                farmerRepository.findById(dto.getFarmerID())
//                        .orElseThrow(() ->
//                                new SchemeApplicationNotFoundException(
//                                        "Farmer not found for: " + dto.getFarmerID()));

        entity.setPolicyscheme(policyScheme);
        entity.setFarmerID(dto.getFarmerID());
        entity.setStatus(dto.getStatus());
        entity.setSubmittedDate(dto.getSubmittedDate());
    }

    private SchemeApplicationResponse toResponse(SchemeApplication s) {

        SchemeApplicationResponse r = new SchemeApplicationResponse();
        r.setApplicationID(s.getApplicationID());
        r.setSchemeID(s.getPolicyscheme().getSchemeID());
        r.setStatus(s.getStatus());
        r.setSubmittedDate(s.getSubmittedDate());

        if (s.getFarmerID() != null) {
            r.setFarmerID(s.getFarmerID());
        }

        return r;
    }

	
}
