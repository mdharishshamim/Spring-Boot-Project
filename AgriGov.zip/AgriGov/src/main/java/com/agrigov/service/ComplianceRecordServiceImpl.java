package com.agrigov.service;

import java.util.List;
import java.util.Objects;
import java.util.stream.Collectors;

import org.springframework.dao.DataIntegrityViolationException;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.agrigov.dto.ComplianceRecordRequest;
import com.agrigov.dto.ComplianceRecordResponse;
import com.agrigov.exception.ResourceNotFoundException;
import com.agrigov.model.ComplianceRecord;
import com.agrigov.model.PolicyScheme;
import com.agrigov.model.RuralProject;
import com.agrigov.model.Subsidy;
import com.agrigov.repository.ComplianceRecordRepository;
import com.agrigov.repository.PolicySchemeRepository;
import com.agrigov.repository.RuralProjectRepository;
import com.agrigov.repository.SubsidyRepository;

import lombok.extern.slf4j.Slf4j;

@Slf4j
@Service
@Transactional // class-level; readOnly is set on query methods below
public class ComplianceRecordServiceImpl implements ComplianceRecordService {

    private final ComplianceRecordRepository complianceRecordRepository;
//    private final PolicySchemeRepository policySchemeRepository;
//    private final SubsidyRepository subsidyRepository;
//    private final RuralProjectRepository ruralProjectRepository;

    public ComplianceRecordServiceImpl(ComplianceRecordRepository complianceRecordRepository,
                                       PolicySchemeRepository policySchemeRepository,
                                       SubsidyRepository subsidyRepository,
                                       RuralProjectRepository ruralProjectRepository) {
        this.complianceRecordRepository = complianceRecordRepository;
//        this.policySchemeRepository = policySchemeRepository;
//        this.subsidyRepository = subsidyRepository;
//        this.ruralProjectRepository = ruralProjectRepository;
    }

    // ---------------------------------------------------------------------
    // CRUD
    // ---------------------------------------------------------------------

    @Override
    @Transactional
    public ComplianceRecordResponse create(ComplianceRecordRequest request) {
    	log.info("creating new compliance");
        ComplianceRecord cr = new ComplianceRecord();

        // If 'complianceno' (PK) is DB-generated, ensure it's null here and add @GeneratedValue in the entity.
        applyPatch(cr, request);

        // Basic guards for required fields on CREATE (entity has nullable=false)
        if (cr.getEntityID() == null ||
            cr.getType() == null ||
            cr.getResult() == null ||
            cr.getNotes() == null
            ) {
            throw new IllegalArgumentException("Missing mandatory fields for ComplianceRecord create");
        }

        cr = complianceRecordRepository.saveAndFlush(cr);
        return toResponse(cr);
    }

    @Override
    @Transactional
    public ComplianceRecordResponse update(Integer complianceId, ComplianceRecordRequest request) {
    	log.info("updating new compliance");
        ComplianceRecord cr = complianceRecordRepository.findById(complianceId)
            .orElseThrow(() -> new ResourceNotFoundException("ComplianceRecord not found: " + complianceId));

        // Keep path ID as source of truth (normalize inbound request)
        if (request.getComplianceId() != null &&
            !Objects.equals(request.getComplianceId(), cr.getComplianceId())) {
            request.setComplianceId(cr.getComplianceId());
        }

        applyPatch(cr, request);

        try {
            cr = complianceRecordRepository.saveAndFlush(cr); // flush to surface constraint violations here
        } catch (DataIntegrityViolationException ex) {
            String msg = ex.getMostSpecificCause() != null ? ex.getMostSpecificCause().getMessage() : ex.getMessage();
            throw new IllegalArgumentException("Invalid ComplianceRecord update: " + msg, ex);
        }

        return toResponse(cr);
    }

    @Override
    @Transactional(readOnly = true)
    public ComplianceRecordResponse get(Integer complianceId) {
    	log.info("getting compliance by id");
        ComplianceRecord cr = complianceRecordRepository.findById(complianceId)
            .orElseThrow(() -> new ResourceNotFoundException("ComplianceRecord not found: " + complianceId));
        return toResponse(cr);
    }

    @Override
    @Transactional(readOnly = true)
    public List<ComplianceRecordResponse> getAll() {
    	log.info("getting compliances");
        return complianceRecordRepository.findAll()
                .stream()
                .map(this::toResponse)
                .collect(Collectors.toList());
    }

    @Override
    @Transactional
    public ComplianceRecordResponse delete(Integer complianceId) {
    	log.info("deleting compliance");
        ComplianceRecord cr = complianceRecordRepository.findById(complianceId)
            .orElseThrow(() -> new ResourceNotFoundException("ComplianceRecord not found: " + complianceId));
        complianceRecordRepository.delete(cr);
        return toResponse(cr);
        
        
    }

    // ---------------------------------------------------------------------
    // Mapping helpers
    // ---------------------------------------------------------------------

    /**
     * Partial update (PATCH semantics): only set fields that are provided (non-null).
     * Does NOT clear fields/associations when request values are null.
     */
    private void applyPatch(ComplianceRecord cr, ComplianceRecordRequest req) {
        // ID — set only if provided (and only if you are NOT using DB-generated ID)
        if (req.getComplianceId() != null) {
            cr.setComplianceId(req.getComplianceId());
        }

        if (req.getEntityID() != null) cr.setEntityID(req.getEntityID());
        if (req.getType() != null) cr.setType(req.getType());
        if (req.getResult() != null) cr.setResult(req.getResult());
        if (req.getNotes() != null) cr.setNotes(req.getNotes());

        // Associations — set only if IDs provided
//        if (req.getSchemeId() != null) {
//            PolicyScheme ps = policySchemeRepository.findById(req.getSchemeId())
//                .orElseThrow(() -> new ResourceNotFoundException("PolicyScheme not found: " + req.getSchemeId()));
//            cr.setPolicyScheme(ps);
//        }
//
//        if (req.getSubsidyId() != null) {
//            Subsidy s = subsidyRepository.findById(req.getSubsidyId())
//                .orElseThrow(() -> new ResourceNotFoundException("Subsidy not found: " + req.getSubsidyId()));
//            cr.setSubsidy(s);
//        }
//
//        if (req.getProjectId() != null) {
//            RuralProject rp = ruralProjectRepository.findById(req.getProjectId())
//                .orElseThrow(() -> new ResourceNotFoundException("RuralProject not found: " + req.getProjectId()));
//            cr.setRuralProject(rp);
//        }
    }

    /** Map entity -> response DTO (Integer types everywhere) */
    private ComplianceRecordResponse toResponse(ComplianceRecord cr) {
        ComplianceRecordResponse r = new ComplianceRecordResponse();
        r.setComplianceId(cr.getComplianceId());
        r.setEntityID(cr.getEntityID());
        r.setType(cr.getType());
        r.setResult(cr.getResult());
        r.setNotes(cr.getNotes());
        r.setDate(cr.getDate());

//        if (cr.getPolicyScheme() != null && cr.getPolicyScheme().getSchemeID() != null) {
//            r.setSchemeId(cr.getPolicyScheme().getSchemeID());
//        }
//        if (cr.getSubsidy() != null && cr.getSubsidy().getSubsidyId() != null) {
//            r.setSubsidyId(cr.getSubsidy().getSubsidyId());
//        }
//        if (cr.getRuralProject() != null && cr.getRuralProject().getProjectId() != null) {
//            r.setProjectId(cr.getRuralProject().getProjectId());
//        }

        return r;
    }
}
