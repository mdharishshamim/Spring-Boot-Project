package com.agrigov.service;

import java.io.IOException;

import java.nio.file.Files;

import java.nio.file.Path;

import java.nio.file.Paths;

import java.time.LocalDate;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;

import org.springframework.beans.factory.annotation.Value;

import org.springframework.stereotype.Service;

import org.springframework.transaction.annotation.Transactional;

import org.springframework.web.multipart.MultipartFile;

import com.agrigov.dto.FarmerDocumentRequest;

import com.agrigov.dto.FarmerDocumentResponse;

import com.agrigov.model.Farmer;

import com.agrigov.model.FarmerDocument;

import com.agrigov.repository.FarmerDocumentRepository;

import com.agrigov.repository.FarmerRepository;

import lombok.extern.slf4j.Slf4j;

@Transactional

@Service

@Slf4j

public class FarmerDocumentServiceImpl implements FarmerDocumentService {

	@Autowired

	private FarmerDocumentRepository documentRepository;

	@Autowired

	private FarmerRepository farmerRepository;

	@Value("${file.upload-dir}")

	private String uploadDir;

	@Override

	public FarmerDocumentResponse uploadDocument(Long farmerId, String docType, MultipartFile file) {

		Farmer farmer = farmerRepository.findById(farmerId)

				.orElseThrow(() -> new RuntimeException("Farmer not found with ID: " + farmerId));

		try {

			Files.createDirectories(Paths.get(uploadDir));

			String fileName = System.currentTimeMillis() + "_" + file.getOriginalFilename();

			Path filePath = Paths.get(uploadDir, fileName);

			log.info("Saving file to absolute path: {}", filePath.toAbsolutePath());

			Files.write(filePath, file.getBytes());

			FarmerDocument document = new FarmerDocument();

			document.setFarmer(farmer);

			document.setDocType(docType);

			document.setFileUri(fileName);

			document.setUploadedDate(LocalDate.now());

			document.setVerificationStatus("Pending");

			FarmerDocument saved = documentRepository.save(document);

			return toResponse(saved);

		} catch (IOException e) {

			log.error("Error saving file", e);

			throw new RuntimeException("File upload failed: " + e.getMessage());

		}

	}

	@Override

	public FarmerDocumentResponse updateDocument(Long documentId, FarmerDocumentRequest request) {

		FarmerDocument existing = documentRepository.findById(documentId)

				.orElseThrow(() -> new RuntimeException("Document not found with ID: " + documentId));

		if (request.getDocType() != null)
			existing.setDocType(request.getDocType());

		if (request.getFileUri() != null)
			existing.setFileUri(request.getFileUri());

		if (request.getUploadedDate() != null)
			existing.setUploadedDate(request.getUploadedDate());

		if (request.getVerificationStatus() != null)
			existing.setVerificationStatus(request.getVerificationStatus());

		if (request.getFarmerId() != null) {

			Farmer farmer = farmerRepository.findById(request.getFarmerId())

					.orElseThrow(() -> new RuntimeException("Farmer not found with ID: " + request.getFarmerId()));

			existing.setFarmer(farmer);

		}

		FarmerDocument updated = documentRepository.save(existing);

		return toResponse(updated);

	}

	@Override

	public FarmerDocumentResponse updateDocument(Long documentId, String docType, MultipartFile file) {

		FarmerDocument existing = documentRepository.findById(documentId)

				.orElseThrow(() -> new RuntimeException("Document not found with ID: " + documentId));

		try {

			if (file != null && !file.isEmpty()) {

				Path oldFilePath = Paths.get(uploadDir, existing.getFileUri());

				Files.deleteIfExists(oldFilePath);

				String fileName = System.currentTimeMillis() + "_" + file.getOriginalFilename();

				Path newFilePath = Paths.get(uploadDir, fileName);

				Files.write(newFilePath, file.getBytes());

				existing.setFileUri(fileName);

				existing.setUploadedDate(LocalDate.now());

			}

			if (docType != null) {

				existing.setDocType(docType);

			}

			existing.setVerificationStatus("Pending");

			FarmerDocument updated = documentRepository.save(existing);

			return toResponse(updated);

		} catch (IOException e) {

			throw new RuntimeException("File update failed: " + e.getMessage());

		}

	}

	@Override

	public void deleteDocument(Long documentId) {

		FarmerDocument doc = documentRepository.findById(documentId)

				.orElseThrow(() -> new RuntimeException("Document not found with ID: " + documentId));

		try {

			Path filePath = Paths.get(uploadDir, doc.getFileUri());

			Files.deleteIfExists(filePath);

		} catch (IOException e) {

			log.error("Failed to delete file from disk: {}", doc.getFileUri(), e);

		}

		documentRepository.deleteById(documentId);

	}

	@Override

	public FarmerDocumentResponse getDocumentById(Long documentId) {

		FarmerDocument doc = documentRepository.findById(documentId)

				.orElseThrow(() -> new RuntimeException("Document not found with ID: " + documentId));

		return toResponse(doc);

	}

	@Override

	public List<FarmerDocumentResponse> getDocumentsByFarmer(Long farmerId) {

		return documentRepository.findByFarmer_FarmerId(farmerId).stream()

				.map(this::toResponse)

				.toList();

	}

	@Override

	public List<FarmerDocumentResponse> getDocumentsByStatus(String status) {

		return documentRepository.findByVerificationStatus(status).stream()

				.map(this::toResponse)

				.toList();

	}

	// Manual mapper: FarmerDocument → FarmerDocumentResponse

	private FarmerDocumentResponse toResponse(FarmerDocument doc) {

		FarmerDocumentResponse response = new FarmerDocumentResponse();

		response.setDocumentId(doc.getDocumentId());

		response.setFarmerId(doc.getFarmer().getFarmerId());

		response.setDocType(doc.getDocType());

		response.setFileUri(doc.getFileUri());

		response.setUploadedDate(doc.getUploadedDate());

		response.setVerificationStatus(doc.getVerificationStatus());

		return response;

	}

}
