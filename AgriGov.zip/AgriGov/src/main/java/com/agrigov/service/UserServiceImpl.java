package com.agrigov.service;

import java.util.List;
import java.util.stream.Collectors;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.agrigov.dto.UserRequest;
import com.agrigov.dto.UserResponse;
import com.agrigov.exception.ResourceNotFoundException;
import com.agrigov.model.User;
import com.agrigov.repository.UserRepository;

@Service
@Transactional(readOnly = true)
public class UserServiceImpl implements UserService {

    private static final Logger log = LoggerFactory.getLogger(UserServiceImpl.class);

    @Autowired
    private final UserRepository userRepository;

    @Autowired
    private final PasswordEncoder passwordEncoder;

    public UserServiceImpl(UserRepository userRepository, PasswordEncoder passwordEncoder) {
        this.userRepository = userRepository;
        this.passwordEncoder = passwordEncoder;
    }

    @Override
    @Transactional
    public UserResponse create(UserRequest request) {
        log.info("Creating new user: {}", request.getEmail());

        User u = new User();
        apply(u, request, true);

        if (request.getPassword() == null || request.getPassword().isBlank()) {
            log.error("Password missing while creating user: {}", request.getEmail());
            throw new IllegalArgumentException("Password is required for user creation");
        }

        u.setPasswordHash(passwordEncoder.encode(request.getPassword()));
        u = userRepository.save(u);

        log.info("User created successfully with ID: {}", u.getUserId());
        return toResponse(u);
    }

    @Override
    @Transactional
    public UserResponse update(Integer UserId, UserRequest request) {
        log.info("Updating user with ID: {}", UserId);

        if (UserId == null) {
            log.error("UserId in update request is null");
            throw new IllegalArgumentException("UserId path parameter cannot be null");
        }

        Long id = UserId.longValue();

        User u = userRepository.findById(id)
                .orElseThrow(() -> {
                    log.error("User not found with ID: {}", UserId);
                    return new ResourceNotFoundException("User not found: " + UserId);
                });

        apply(u, request, true);

        if (request.getPassword() != null && !request.getPassword().isBlank()) {
            log.debug("Updating password for user ID: {}", UserId);
            u.setPasswordHash(passwordEncoder.encode(request.getPassword()));
        }

        u = userRepository.save(u);
        log.info("User updated successfully with ID: {}", UserId);

        return toResponse(u);
    }

    @Override
    public UserResponse get(Integer UserId) {
        log.debug("Fetching user with ID: {}", UserId);

        if (UserId == null) {
            log.error("UserId in get request is null");
            throw new IllegalArgumentException("UserId path parameter cannot be null");
        }

        Long id = UserId.longValue();

        User u = userRepository.findById(id)
                .orElseThrow(() -> {
                    log.error("User not found: {}", UserId);
                    return new ResourceNotFoundException("User not found: " + UserId);
                });

        return toResponse(u);
    }

    @Override
    public List<UserResponse> getAll() {
        log.debug("Fetching all users");
        return userRepository.findAll().stream().map(this::toResponse).collect(Collectors.toList());
    }

    @Override
    @Transactional
    public void delete(Integer UserId) {
        log.warn("Deleting user with ID: {}", UserId);

        if (UserId == null) {
            log.error("UserId in delete request is null");
            throw new IllegalArgumentException("UserId path parameter cannot be null");
        }

        Long id = UserId.longValue();

        User u = userRepository.findById(id)
                .orElseThrow(() -> {
                    log.error("User not found for deletion: {}", UserId);
                    return new ResourceNotFoundException("User not found: " + UserId);
                });

        userRepository.delete(u);
        log.info("User deleted successfully with ID: {}", UserId);
    }

    // --- Mapping Helpers (unchanged) ---
    private void apply(User u, UserRequest req, boolean clearOnNull) {
        if (clearOnNull || req.getName() != null) u.setName(req.getName());
        if (clearOnNull || req.getRole() != null) u.setRole(req.getRole());
        if (clearOnNull || req.getEmail() != null) u.setEmail(req.getEmail());

        u.setPhone(req.getPhone());
        u.setStatus(req.isStatus());
    }

    private UserResponse toResponse(User u) {
        UserResponse r = new UserResponse();
        if (u.getUserId() != null) r.setUserId(u.getUserId().intValue());

        r.setName(u.getName());
        r.setRole(u.getRole());
        r.setEmail(u.getEmail());
        r.setPhone(u.getPhone());
        r.setStatus(u.isStatus());

        return r;
    }
}