package com.agrigov.service;

import java.util.List;

import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.agrigov.dto.SubsidyRequest;
import com.agrigov.dto.SubsidyResponse;
import com.agrigov.model.Farmer;
import com.agrigov.model.PolicyScheme;
import com.agrigov.model.Subsidy;
import com.agrigov.repository.FarmerRepository;
import com.agrigov.repository.PolicySchemeRepository;
import com.agrigov.repository.SubsidyRepository;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;

@Service
@RequiredArgsConstructor
@Transactional
@Slf4j
public class SubsidyServiceImpl implements SubsidyService {

	private final SubsidyRepository subsidyRepository;
	private final PolicySchemeRepository policySchemeRepository;
	private final FarmerRepository farmerRepository;

	@Override
	public SubsidyResponse create(SubsidyRequest request) {
		log.info("subsidy create");
		PolicyScheme scheme = policySchemeRepository.findById(request.getSchemeId()).orElseThrow(() -> {
			log.warn("scheme not found id={}", request.getSchemeId());
			return new IllegalArgumentException("PolicyScheme not found: " + request.getSchemeId());
		});

		Farmer farmer = farmerRepository.findById(request.getFarmerId()).orElseThrow(() -> {
			log.warn("farmer not found id={}", request.getFarmerId());
			return new IllegalArgumentException("Farmer not found: " + request.getFarmerId());
		});

		Subsidy entity = Subsidy.builder().scheme(scheme).farmer(farmer).amount(request.getAmount())
				.date(request.getDate()).status(request.getStatus()).build();

		Subsidy saved = subsidyRepository.save(entity);
		log.info("subsidy created id={}", saved.getSubsidyId());
		return toResponse(saved);
	}

	@Override
	@Transactional(readOnly = true)
	public List<SubsidyResponse> getAll() {
		log.info("subsidy list");
		List<SubsidyResponse> list = subsidyRepository.findAll().stream().map(this::toResponse).toList();
		log.info("total subsidies={}", list.size());
		return list;
	}

	@Override
	@Transactional(readOnly = true)
	public SubsidyResponse getById(Long subsidyId) {
		log.info("subsidy get id={}", subsidyId);
		Subsidy found = subsidyRepository.findById(subsidyId).orElseThrow(() -> {
			log.warn("subsidy not found id={}", subsidyId);
			return new IllegalArgumentException("Subsidy not found: " + subsidyId);
		});
		log.info("subsidy found id={}", found.getSubsidyId());
		return toResponse(found);
	}

	@Override
	public SubsidyResponse update(Long subsidyId, SubsidyRequest request) {
		log.info("subsidy update id={}", subsidyId);
		Subsidy existing = subsidyRepository.findById(subsidyId).orElseThrow(() -> {
			log.warn("subsidy not found id={}", subsidyId);
			return new IllegalArgumentException("Subsidy not found: " + subsidyId);
		});

		if (request.getSchemeId() != null) {
			Long currentSchemeId = existing.getScheme() != null ? existing.getScheme().getSchemeID() : null;
			if (!request.getSchemeId().equals(currentSchemeId)) {
				PolicyScheme scheme = policySchemeRepository.findById(request.getSchemeId()).orElseThrow(() -> {
					log.warn("scheme not found id={}", request.getSchemeId());
					return new IllegalArgumentException("PolicyScheme not found: " + request.getSchemeId());
				});
				existing.setScheme(scheme);
				log.info("scheme set id={}", request.getSchemeId());
			}
		}

		if (request.getFarmerId() != null) {
			Long currentFarmerId = existing.getFarmer() != null ? existing.getFarmer().getFarmerId() : null;
			if (!request.getFarmerId().equals(currentFarmerId)) {
				Farmer farmer = farmerRepository.findById(request.getFarmerId()).orElseThrow(() -> {
					log.warn("farmer not found id={}", request.getFarmerId());
					return new IllegalArgumentException("Farmer not found: " + request.getFarmerId());
				});
				existing.setFarmer(farmer);
				log.info("farmer set id={}", request.getFarmerId());
			}
		}

		existing.setAmount(request.getAmount());
		existing.setDate(request.getDate());
		existing.setStatus(request.getStatus());

		Subsidy saved = subsidyRepository.save(existing);
		log.info("subsidy updated id={}", saved.getSubsidyId());
		return toResponse(saved);
	}

	@Override
	public void delete(Long subsidyId) {
		log.info("subsidy delete id={}", subsidyId);
		if (!subsidyRepository.existsById(subsidyId)) {
			log.warn("subsidy not found id={}", subsidyId);
			throw new IllegalArgumentException("Subsidy not found: " + subsidyId);
		}
		subsidyRepository.deleteById(subsidyId);
		log.info("subsidy deleted id={}", subsidyId);
	}

	private SubsidyResponse toResponse(Subsidy s) {
		return SubsidyResponse.builder().subsidyId(s.getSubsidyId())
				.schemeId(s.getScheme() != null ? s.getScheme().getSchemeID() : null)
				.farmerId(s.getFarmer() != null ? s.getFarmer().getFarmerId() : null).amount(s.getAmount())
				.date(s.getDate()).status(s.getStatus()).build();
	}
}