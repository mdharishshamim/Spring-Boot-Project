package com.agrigov.dto;

import com.agrigov.enums.Role;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import lombok.Data;

@Data
public class UserRequest {
   // @NotNull(message = "user ID is required")
    private Integer userId;

    @NotBlank(message = "User name is required")
    private String name;

    @NotBlank(message = "Email is required")
    private String email;

    @NotNull(message = "Phone number is required")
    private long phone;

    private Role role;

    private boolean status;
    

    private String password;


}