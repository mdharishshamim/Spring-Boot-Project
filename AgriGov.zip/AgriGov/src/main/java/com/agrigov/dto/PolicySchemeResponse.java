package com.agrigov.dto;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.math.BigDecimal;
import java.time.LocalDate;

/**
 * Response DTO for PolicyScheme.
 * Mirrors ERD fields and includes the primary key.
 */
@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class PolicySchemeResponse {

    private Long schemeID;
    private String title;
    private String description;
    private LocalDate startDate;
    private LocalDate endDate;
    private BigDecimal budget;
    private String status;
}