package com.agrigov.dto;

import java.time.LocalDateTime;

import lombok.Data;

@Data
public class AuditLogResponse {
	private Integer AuditId;
	private Integer UserId;
	private String Action;
	private String Resource;
	private LocalDateTime Timestamp;
}