package com.agrigov.dto;

import java.time.LocalDate;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class ComplianceRecordResponse {
	
	private Long complianceId;
	private Long entityID;
	private String type;
	private String result;
	private String notes;
	private LocalDate date;

//	private Long schemeId;
//	private Long subsidyId;
//	private Long projectId;
}
