package com.agrigov.dto;

import java.math.BigDecimal;
import java.time.LocalDate;

import lombok.Builder;
import lombok.Data;

@Data
@Builder
public class SubsidyResponse {
    private Long subsidyId;
    private Long schemeId;
    private Long farmerId;
    private BigDecimal amount;
    private LocalDate date;
    private String status;
}