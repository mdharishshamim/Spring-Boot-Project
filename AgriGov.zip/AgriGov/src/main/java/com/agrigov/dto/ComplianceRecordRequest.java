package com.agrigov.dto;


import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class ComplianceRecordRequest {
	
	private Long complianceId;
	private Long entityID;

	private String type;

	private String result;

	private String notes;


//	private Long schemeId;
//	private Long subsidyId;
//	private Long projectId;
}
