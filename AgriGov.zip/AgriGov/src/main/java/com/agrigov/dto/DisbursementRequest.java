package com.agrigov.dto;

import java.time.LocalDate;

import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import lombok.Data;

@Data
public class DisbursementRequest {

	@NotNull(message = "subsidyId is required")
	private Long subsidyId;
	
	@NotNull(message = "officerId is required")
	private Long officerId;

	@NotNull(message = "date is required")
	private LocalDate date;

	@NotBlank(message = "status is required")
	private String status;
}