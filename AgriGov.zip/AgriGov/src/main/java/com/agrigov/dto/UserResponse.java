package com.agrigov.dto;

import com.agrigov.enums.Role;
import lombok.Data;

@Data
public class UserResponse {
        private int userId;
        private String name;
        private Role role;
        private String email;
        private long phone;
        private boolean status;
        
    }