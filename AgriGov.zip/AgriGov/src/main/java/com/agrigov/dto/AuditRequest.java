package com.agrigov.dto;


import com.agrigov.model.User;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class AuditRequest {
	private Long auditId;
	private Long userId;
	private String scope;
	private String findings;
	private String status;
}
