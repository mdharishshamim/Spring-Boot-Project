package com.agrigov.dto;

import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Size;
import lombok.Data;

@Data
public class AuditLogRequest {
	
	

	    @NotNull(message = "UserID is required")
	    private Integer UserId;

	    @NotBlank(message = "Action is required")
	    @Size(max = 50, message = "Action must be <= 50 characters")
	    private String Action; // or use enum ActionType

	    @NotBlank(message = "Resource is required")
	    @Size(max = 255, message = "Resource must be <= 255 characters")
	    private String Resource;

	}
