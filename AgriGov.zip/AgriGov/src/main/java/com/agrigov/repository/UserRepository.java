package com.agrigov.repository;

import com.agrigov.model.User;

import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface UserRepository extends JpaRepository<User, Long> {

	Optional<User> findByEmailIgnoreCase(String Email);

	Optional<User> findByNameIgnoreCase(String Name);

}