package com.agrigov.repository;

import java.util.List;
import org.springframework.data.jpa.repository.JpaRepository;
import com.agrigov.model.FarmerDocument;

public interface FarmerDocumentRepository extends JpaRepository<FarmerDocument, Long> {
    List<FarmerDocument> findByFarmer_FarmerId(Long farmerId);
    List<FarmerDocument> findByVerificationStatus(String status);
}
