package com.agrigov.model;

import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDateTime;

@Entity
@Data
@NoArgsConstructor
@AllArgsConstructor
@Table(name = "audit_log")
public class AuditLog {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "audit_id", nullable = false)
	private int AuditId;
	
	@Column(name = "user_id", nullable = false)
	private int UserId;

	@Column(name = "timestamp", nullable = false)
	private LocalDateTime Timestamp;

	@Column(name = "resources")
	private String Resource;

	@Column(name = "actions", nullable = false)
	private String Action;
}