package com.agrigov.model;

import java.time.LocalDate;
import jakarta.persistence.*;
import lombok.Data;

@Entity
@Table(name = "FarmerDocument")
@Data
public class FarmerDocument {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long documentId;

	@ManyToOne
	@JoinColumn(name = "farmerId", nullable = false)
	private Farmer farmer;

	@Column(nullable = false, length = 50)
	private String docType;

	@Column(nullable = false, length = 255)
	private String fileUri; // filename or relative path

	@Column(nullable = false)
	private LocalDate uploadedDate;

	@Column(length = 20)
	private String verificationStatus; // Pending / Verified / Rejected
}