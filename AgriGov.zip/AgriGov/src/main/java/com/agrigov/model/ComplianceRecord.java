package com.agrigov.model;

import java.time.LocalDate;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.FetchType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.PrePersist;
import jakarta.persistence.Table;
import jakarta.validation.constraints.NotBlank;
import lombok.AllArgsConstructor;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;


@Entity
@Table(name = "Compliances")

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@EqualsAndHashCode(onlyExplicitlyIncluded = true)
@ToString(onlyExplicitlyIncluded = true)
public class ComplianceRecord {

	@Id
	@Column(name = "complianceno", nullable = false)
	private Long complianceId;

	@Column(name = "entityID", nullable = false)
	private Long entityID;

	@Column(name = "Type", nullable = false, length = 50)
	@NotBlank(message = "Entity Type is required")
	private String type;
	
	@Column(name = "Result", nullable = false, length = 50)
	@NotBlank(message = "Compliance Result is required")
	private String result;

	@Column(name = "Notes", nullable = false, length = 50)
	@NotBlank(message = "Compliance Notes is required")
	private String notes;
	

    @Column(name = "Date", updatable = false)
    private LocalDate date;

    @PrePersist
    public void prePersist() {
        this.date = LocalDate.now();
    }

	
		
	    @ManyToOne(fetch = FetchType.LAZY, optional = true)
	    @JoinColumn(name = "policyscheme_id") // match actual column name
	    private PolicyScheme policyScheme;

	    @ManyToOne(fetch = FetchType.LAZY, optional = true)
	    @JoinColumn(name = "subsidy_id")
	    private Subsidy subsidy;

	    @ManyToOne(fetch = FetchType.LAZY, optional = true)
	    @JoinColumn(name = "project_id")
	    private RuralProject ruralProject;


	}



