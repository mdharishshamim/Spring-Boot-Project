package com.agrigov.model;

import com.agrigov.enums.Role;
import com.fasterxml.jackson.annotation.JsonIgnore;

import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Entity
@Data
@AllArgsConstructor
@NoArgsConstructor
@Table(name = "users")
public class User {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "user_id", nullable = false)
	private Long userId;

	@Column(name = "name", nullable = false)
	private String name;

	@Enumerated(EnumType.STRING)
	@Column(name = "role", nullable = false)
	private Role role;

	@Column(name = "email", nullable = false)
	private String email;

	@Column(name = "phone_no", nullable = false)
	private long phone;

	@Column(name = "status", nullable = false)
	private boolean status;


	 @JsonIgnore     //stores only the hash
	 @Column(name = "password_hash", nullable = false, length = 100)
	 private String passwordHash;

}