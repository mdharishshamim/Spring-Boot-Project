package com.agrigov.exception;

public class MilestoneNotFound extends RuntimeException{
	public MilestoneNotFound(String message) {
		super(message);
	}
}
