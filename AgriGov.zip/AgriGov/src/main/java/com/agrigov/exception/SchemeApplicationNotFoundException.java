package com.agrigov.exception;

public class SchemeApplicationNotFoundException extends RuntimeException{

	public SchemeApplicationNotFoundException(String message) {
		super(message);
	}

}