package com.agrigov.exception;

public class ReportResponseNotFoundException  extends RuntimeException{
	public ReportResponseNotFoundException(String message){
        super(message);
    }
}
