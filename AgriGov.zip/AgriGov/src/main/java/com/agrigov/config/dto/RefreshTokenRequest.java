package com.agrigov.config.dto;

import lombok.Data;

@Data
public class RefreshTokenRequest {

    private String refreshToken;

}