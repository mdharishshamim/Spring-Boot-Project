package com.agrigov.config;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.http.HttpMethod;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.config.annotation.authentication.configuration.AuthenticationConfiguration;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configurers.AbstractHttpConfigurer;
import org.springframework.security.config.http.SessionCreationPolicy;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.security.web.SecurityFilterChain;
import org.springframework.security.web.authentication.UsernamePasswordAuthenticationFilter;

@Configuration
public class SecurityConfig {

    @Bean
    public PasswordEncoder passwordEncoder() {
        return new BCryptPasswordEncoder(); // default strength 10
    }

    @Bean
    public SecurityFilterChain securityFilterChain(HttpSecurity http, JwtService jwtService) throws Exception {

        JwtAuthenticationFilter jwtFilter = new JwtAuthenticationFilter(jwtService);

        http
            // Stateless REST API
            .sessionManagement(sm -> sm.sessionCreationPolicy(SessionCreationPolicy.STATELESS))

            // CSRF disabled for APIs; also ignore h2-console
            .csrf(csrf -> csrf
                .ignoringRequestMatchers("/h2-console/**")
                .disable()
            )

            // Authorize requests
            .authorizeHttpRequests(auth -> auth
                .requestMatchers("/auth/**", "/h2-console/**").permitAll()
                //.requestMatchers(HttpMethod.PUT, "/api/users/*").permitAll()
                //.requestMatchers(HttpMethod.POST, "/users").permitAll()        // Register is onlypublic in this case others will require bearer token
                .requestMatchers("/api/users/**").permitAll()
                // Adjust role-protected routes to your app
                //below are for audit log
                //.requestMatchers(HttpMethod.GET, "/audit-logs").hasAnyRole("ADMIN","COMPLIANCEOFFICER","GOVERNMENTAUDITOR")
                //.requestMatchers(HttpMethod.GET, "/audit-logs/*").hasAnyRole("ADMIN","COMPLIANCEOFFICER","GOVERNMENTAUDITOR")
                .requestMatchers(HttpMethod.GET, "/audit-logs").permitAll()
                .requestMatchers(HttpMethod.GET, "/audit-logs/*").permitAll()
                .requestMatchers("/api/audits/**").permitAll()
                .requestMatchers("/api/audit-logs/**").permitAll()
                .requestMatchers("/api/compliance-records/**").permitAll()
                .requestMatchers("/application/**").permitAll()
                .requestMatchers("/policy/**").permitAll()
                .requestMatchers("/farmers/**").permitAll()
                .requestMatchers("/dashboard/**").permitAll()
                .requestMatchers("/documents/**").permitAll()
                .requestMatchers("/subsidies/**").permitAll()
                .requestMatchers("/disbursements/**").permitAll()
                .requestMatchers("/admin/**").hasRole("ADMIN")
                .requestMatchers("/farmer/**").hasAnyRole("FARMER","ADMIN")
                .anyRequest().authenticated()
            )

            // Allow H2 console to render in frames
            .headers(headers -> headers.frameOptions(frame -> frame.sameOrigin()))

            // Plug in JWT filter
            .addFilterBefore(jwtFilter, UsernamePasswordAuthenticationFilter.class)

            // Disable default login/logout UIs for pure API
            .httpBasic(AbstractHttpConfigurer::disable)
            .formLogin(AbstractHttpConfigurer::disable)
            .logout(AbstractHttpConfigurer::disable);

        return http.build();
    }

    @Bean
    public AuthenticationManager authenticationManager(AuthenticationConfiguration cfg) throws Exception {
        return cfg.getAuthenticationManager();
    }
}