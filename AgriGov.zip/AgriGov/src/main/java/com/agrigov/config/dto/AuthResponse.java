package com.agrigov.config.dto;

import com.agrigov.dto.UserResponse;

import lombok.Data;

@Data
public class AuthResponse {

    private String accessToken;
    private String refreshToken;
    private String tokenType; // "Bearer"
    private long expiresIn;
    private UserResponse user;

}