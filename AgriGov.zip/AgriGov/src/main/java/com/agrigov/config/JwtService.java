package com.agrigov.config;

import java.nio.charset.StandardCharsets;
import java.time.Instant;
import java.util.Date;

import javax.crypto.SecretKey;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import com.agrigov.model.User;

import io.jsonwebtoken.Claims;
import io.jsonwebtoken.Jws;
import io.jsonwebtoken.Jwts;
import io.jsonwebtoken.SignatureAlgorithm;
import io.jsonwebtoken.security.Keys;

@Service
public class JwtService {

    private final SecretKey accessKey;
    private final SecretKey refreshKey;
    private final long accessTtlMillis;
    private final long refreshTtlMillis;
    private final boolean rotateRefreshTokens;

    public JwtService(
            @Value("${jwt.access.secret}") String accessSecret,
            @Value("${jwt.refresh.secret}") String refreshSecret,
            @Value("${jwt.access.ttl-seconds:900}") long accessTtlSeconds,
            @Value("${jwt.refresh.ttl-seconds:2592000}") long refreshTtlSeconds,
            @Value("${jwt.refresh.rotate:true}") boolean rotateRefreshTokens
    ) {
        this.accessKey = Keys.hmacShaKeyFor(accessSecret.getBytes(StandardCharsets.UTF_8));
        this.refreshKey = Keys.hmacShaKeyFor(refreshSecret.getBytes(StandardCharsets.UTF_8));
        this.accessTtlMillis = accessTtlSeconds * 1000;
        this.refreshTtlMillis = refreshTtlSeconds * 1000;
        this.rotateRefreshTokens = rotateRefreshTokens;
    }

    public long getAccessTokenTtlSeconds() {
        return accessTtlMillis / 1000;
    }

    public boolean rotateRefreshTokens() {
        return rotateRefreshTokens;
    }

    public String generateAccessToken(User u) {
        Instant now = Instant.now();
        return Jwts.builder()
                .setSubject(u.getEmail())
                .setIssuedAt(Date.from(now))
                .setExpiration(Date.from(now.plusMillis(accessTtlMillis)))
                .claim("uid", u.getUserId())
                .claim("role", u.getRole() == null ? null : u.getRole().name())
                .claim("email", u.getEmail())
                .claim("typ", "access")
                .signWith(accessKey, SignatureAlgorithm.HS256)
                .compact();
    }

    public String generateRefreshToken(User u) {
        Instant now = Instant.now();
        return Jwts.builder()
                .setSubject(u.getEmail())
                .setIssuedAt(Date.from(now))
                .setExpiration(Date.from(now.plusMillis(refreshTtlMillis)))
                .claim("uid", u.getUserId())
                .claim("email", u.getEmail())
                .claim("typ", "refresh")
                .signWith(refreshKey, SignatureAlgorithm.HS256)
                .compact();
    }

    public Jws<Claims> parseAndValidateAccessToken(String token) {
        return Jwts.parserBuilder()
                .require("typ", "access")
                .setSigningKey(accessKey)
                .build()
                .parseClaimsJws(token);
    }

    public Claims parseAndValidateRefreshToken(String token) {
        return Jwts.parserBuilder()
                .require("typ", "refresh")
                .setSigningKey(refreshKey)
                .build()
                .parseClaimsJws(token)
                .getBody();
    }
}