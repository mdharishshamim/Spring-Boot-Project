package com.agrigov.enums;

public enum ComplianceType {
    Subsidy,
    Scheme,
    Project
}