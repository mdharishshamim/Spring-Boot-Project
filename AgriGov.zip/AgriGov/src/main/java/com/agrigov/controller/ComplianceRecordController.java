package com.agrigov.controller;

import java.util.List;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.agrigov.dto.ComplianceRecordRequest;
import com.agrigov.dto.ComplianceRecordResponse;
import com.agrigov.service.ComplianceRecordService;

import jakarta.validation.Valid;
import lombok.extern.slf4j.Slf4j;

@Slf4j
@RestController
@RequestMapping("/api/compliance-records")
public class ComplianceRecordController {
	private final ComplianceRecordService complianceRecordService;

	public ComplianceRecordController(ComplianceRecordService complianceRecordService) {
		this.complianceRecordService = complianceRecordService;
	}

	@PostMapping("/save") // http://localhost:1234/api/compliance-records/save
	public ResponseEntity<ComplianceRecordResponse> create(@Valid @RequestBody ComplianceRecordRequest request) {
		log.info("Compliance Saved");
		return ResponseEntity.status(HttpStatus.CREATED).body(complianceRecordService.create(request));
	}

	@GetMapping("fetchById/{id}")
	public ResponseEntity<ComplianceRecordResponse> get(@PathVariable Integer id) {
		log.info("Getting Compliance By Id");
		return ResponseEntity.ok(complianceRecordService.get(id));
	}

	@GetMapping("fetchAll")
	public ResponseEntity<List<ComplianceRecordResponse>> all() {
		log.info("Getting all compliances");
		return ResponseEntity.ok(complianceRecordService.getAll());
	}

	@PutMapping("updateCompliance/{id}")
	public ResponseEntity<ComplianceRecordResponse> update(@PathVariable Integer id,
			@Valid @RequestBody ComplianceRecordRequest request) {
		log.info("Compliance Updated");
		return ResponseEntity.ok(complianceRecordService.update(id, request));
	}

	@DeleteMapping("delete/{id}")
	public ResponseEntity<ComplianceRecordResponse> delete(@PathVariable Integer id) {

		ComplianceRecordResponse deletedRecord = complianceRecordService.get(id);
		complianceRecordService.delete(id);
		log.info("Compliance Deleted");
		return ResponseEntity.ok(deletedRecord);

	}

}
