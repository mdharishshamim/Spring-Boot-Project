package com.agrigov.controller;

import java.util.List;

import org.springframework.web.bind.annotation.*;

import com.agrigov.dto.FarmerResponse;
import com.agrigov.service.FarmerService;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;

@RestController
@RequestMapping("/dashboard")
@RequiredArgsConstructor
@Slf4j
public class DashBoardController {

    private final FarmerService farmerService;

    // Get all farmers with their documents
    @GetMapping
    public List<FarmerResponse> getAllFarmersWithDocuments() {
        log.info("Fetching dashboard: all farmers with documents");
        return farmerService.getAllFarmers();
    }

    // Get farmer by ID with documents
    @GetMapping("/{farmerId}")
    public FarmerResponse getFarmerWithDocuments(@PathVariable Long farmerId) {
        log.info("Fetching dashboard: farmer with ID {}", farmerId);
        return farmerService.getFarmerById(farmerId);
    }

    // Get farmers filtered by status (Active/Inactive)
    @GetMapping("/status/{status}")
    public List<FarmerResponse> getFarmersByStatus(@PathVariable String status) {
        log.info("Fetching dashboard: farmers with status {}", status);
        return farmerService.getFarmersByStatus(status);
    }
}
