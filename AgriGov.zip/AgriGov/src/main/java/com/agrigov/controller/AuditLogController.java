package com.agrigov.controller;

import com.agrigov.dto.AuditLogResponse;
import com.agrigov.service.AuditLogService;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/audit-logs")
public class AuditLogController {

    private static final Logger log = LoggerFactory.getLogger(AuditLogController.class);

    private final AuditLogService service;

    @Autowired
    public AuditLogController(AuditLogService service) {
        this.service = service;
    }

    @GetMapping("/{auditId}")
    public ResponseEntity<AuditLogResponse> getAuditLog(@PathVariable("auditId") Integer auditId) {
        log.info("API: Request received to fetch audit log with ID: {}", auditId);

        AuditLogResponse response = service.get(auditId);

        log.debug("API: Successfully returning audit log with ID: {}", auditId);
        return ResponseEntity.ok(response);
    }

    @GetMapping
    public ResponseEntity<List<AuditLogResponse>> getAllAuditLogs() {
        log.info("API: Request received to fetch all audit logs");

        List<AuditLogResponse> all = service.getAll();

        log.debug("API: Returning {} audit logs", all.size());
        return ResponseEntity.ok(all);
    }
}
