package com.agrigov.controller;

import com.agrigov.dto.PolicySchemeRequest;
import com.agrigov.dto.PolicySchemeResponse;
import com.agrigov.service.PolicySchemeService;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequiredArgsConstructor
@RequestMapping("/policy")
public class PolicySchemeController {

    private final PolicySchemeService service;

    @PostMapping
    @ResponseStatus(HttpStatus.CREATED)
    public PolicySchemeResponse create(@Valid @RequestBody PolicySchemeRequest request) {
        return service.create(request);
    }

    @GetMapping("/fetchall")
    public List<PolicySchemeResponse> getAll() {
        return service.getAll();
    }

    @GetMapping("/{schemeID}")
    public PolicySchemeResponse getById(@PathVariable Long schemeID) {
        return service.getById(schemeID);
    }

    @PutMapping("/{schemeID}")
    public PolicySchemeResponse update(@PathVariable Long schemeID,
                                       @Valid @RequestBody PolicySchemeRequest request) {
        return service.update(schemeID, request);
    }

    @DeleteMapping("/{schemeID}")
    @ResponseStatus(HttpStatus.NO_CONTENT)
    public void delete(@PathVariable Long schemeID) {
        service.delete(schemeID);
    }
}