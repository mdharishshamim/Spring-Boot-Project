package com.agrigov.controller;

import com.agrigov.dto.UserRequest;
import com.agrigov.dto.UserResponse;
import com.agrigov.service.UserService;

import jakarta.validation.Valid;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.net.URI;
import java.util.List;

@RestController
@RequestMapping("/api/users")
public class UserController {

    private static final Logger log = LoggerFactory.getLogger(UserController.class);

    private final UserService service;

    @Autowired
    public UserController(UserService service) {
        this.service = service;
    }

    @PostMapping
    public ResponseEntity<UserResponse> createUser(@Valid @RequestBody UserRequest request) {
        log.info("API: Create user request received: {}", request.getEmail());
        UserResponse created = service.create(request);

        URI location = URI.create("/api/users/" + created.getUserId());
        return ResponseEntity.created(location).body(created);
    }

    @PutMapping("/{id}")
    public ResponseEntity<UserResponse> updateUser(
            @PathVariable("id") Integer userId,
            @Valid @RequestBody UserRequest request) {

        log.info("API: Update user request for ID: {}", userId);
        UserResponse updated = service.update(userId, request);
        return ResponseEntity.ok(updated);
    }

    @GetMapping("/{id}")
    public ResponseEntity<UserResponse> getUser(@PathVariable("id") Integer userId) {
        log.debug("API: Fetch user request for ID: {}", userId);
        UserResponse response = service.get(userId);
        return ResponseEntity.ok(response);
    }

    @GetMapping
    public ResponseEntity<List<UserResponse>> getAllUsers() {
        log.debug("API: Fetch all users");
        List<UserResponse> all = service.getAll();
        return ResponseEntity.ok(all);
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> deleteUser(@PathVariable("id") Integer userId) {
        log.warn("API: Delete user request for ID: {}", userId);
        service.delete(userId);
        return ResponseEntity.noContent().build();
    }
}