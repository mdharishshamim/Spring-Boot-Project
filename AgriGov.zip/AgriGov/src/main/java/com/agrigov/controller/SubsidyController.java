package com.agrigov.controller;

import java.util.List;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.agrigov.dto.SubsidyRequest;
import com.agrigov.dto.SubsidyResponse;
import com.agrigov.service.SubsidyService;

import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;

@RestController
@RequestMapping("/subsidies")
@RequiredArgsConstructor
@Validated
@Slf4j
public class SubsidyController {

	private final SubsidyService subsidyService;

	@PostMapping
	public ResponseEntity<SubsidyResponse> create(@Valid @RequestBody SubsidyRequest request) {

		log.info("Creating subsidy with request: {}", request);

		SubsidyResponse response = subsidyService.create(request);

		log.info("Subsidy created successfully with response: {}", response);

		return ResponseEntity.status(HttpStatus.CREATED).body(response);
	}

	@GetMapping
	public ResponseEntity<List<SubsidyResponse>> getAll() {

		log.info("Fetching all subsidies");

		return ResponseEntity.ok(subsidyService.getAll());
	}

	@GetMapping("/{id}")
	public ResponseEntity<SubsidyResponse> getById(@PathVariable("id") Long id) {

		log.info("Fetching subsidy with id: {}", id);

		return ResponseEntity.ok(subsidyService.getById(id));
	}

	@PutMapping("/{id}")
	public ResponseEntity<SubsidyResponse> update(@PathVariable("id") Long id,
			@Valid @RequestBody SubsidyRequest request) {

		log.info("Updating subsidy with id: {}", id);

		return ResponseEntity.ok(subsidyService.update(id, request));
	}

	@DeleteMapping("/{id}")
	public ResponseEntity<String> delete(@PathVariable("id") Long id) {

		log.info("Deleting subsidy with id: {}", id);

		subsidyService.delete(id);

		log.info("Subsidy deleted successfully with id: {}", id);

		return ResponseEntity.ok("Subsidy deleted successfully");
	}
}