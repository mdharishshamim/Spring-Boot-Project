package com.agrigov.controller;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.ResponseEntity;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.agrigov.config.JwtService;
import com.agrigov.config.dto.AuthRequest;
import com.agrigov.config.dto.AuthResponse;
import com.agrigov.config.dto.RefreshTokenRequest;
import com.agrigov.dto.UserResponse;
import com.agrigov.model.User;
import com.agrigov.repository.UserRepository;

@RestController
@RequestMapping("/auth")
public class AuthController {

    private static final Logger log = LoggerFactory.getLogger(AuthController.class);

    private final UserRepository userRepository;
    private final PasswordEncoder passwordEncoder;
    private final JwtService jwtService;

    public AuthController(UserRepository userRepository,
                          PasswordEncoder passwordEncoder,
                          JwtService jwtService) {
        this.userRepository = userRepository;
        this.passwordEncoder = passwordEncoder;
        this.jwtService = jwtService;
    }

    @PostMapping("/login")
    public ResponseEntity<AuthResponse> login(@RequestBody AuthRequest req) {

        log.info("Login attempt for: {}", req.getUsernameOrEmail());

        if ((req.getUsernameOrEmail() == null || req.getUsernameOrEmail().isBlank())
                || (req.getPassword() == null || req.getPassword().isBlank())) {
            log.warn("Login request missing username or password.");
            return ResponseEntity.badRequest().build();
        }

        User user = userRepository.findByEmailIgnoreCase(req.getUsernameOrEmail())
                .or(() -> userRepository.findByNameIgnoreCase(req.getUsernameOrEmail()))
                .orElseThrow(() -> {
                    log.error("Invalid login: User not found: {}", req.getUsernameOrEmail());
                    return new RuntimeException("Invalid credentials");
                });

        if (!passwordEncoder.matches(req.getPassword(), user.getPasswordHash())) {
            log.error("Invalid login: Password mismatch for user {}", req.getUsernameOrEmail());
            throw new RuntimeException("Invalid credentials");
        }

        log.info("Login successful for user {}", user.getEmail());

        String accessToken = jwtService.generateAccessToken(user);
        String refreshToken = jwtService.generateRefreshToken(user);

        AuthResponse resp = new AuthResponse();
        resp.setAccessToken(accessToken);
        resp.setRefreshToken(refreshToken);
        resp.setTokenType("Bearer");
        resp.setExpiresIn(jwtService.getAccessTokenTtlSeconds());
        resp.setUser(toResponse(user));

        return ResponseEntity.ok(resp);
    }

    @PostMapping("/refresh-token")
    public ResponseEntity<AuthResponse> refresh(@RequestBody RefreshTokenRequest req) {

        log.info("Refresh token request received");

        if (req.getRefreshToken() == null || req.getRefreshToken().isBlank()) {
            log.warn("Refresh token missing from request");
            return ResponseEntity.badRequest().build();
        }

        var claims = jwtService.parseAndValidateRefreshToken(req.getRefreshToken());
        Long userId = claims.get("uid", Long.class);
        String email = claims.get("email", String.class);

        log.debug("Refresh token -> UserId: {}, Email: {}", userId, email);

        User user = userRepository.findById(userId)
                .filter(u -> u.getEmail().equalsIgnoreCase(email))
                .orElseThrow(() -> {
                    log.error("Invalid refresh token: user mismatch");
                    return new RuntimeException("Invalid refresh token");
                });

        log.info("Refresh token validated successfully for user {}", user.getEmail());

        String newAccess = jwtService.generateAccessToken(user);
        String newRefresh = jwtService.rotateRefreshTokens()
                ? jwtService.generateRefreshToken(user)
                : req.getRefreshToken();

        AuthResponse resp = new AuthResponse();
        resp.setAccessToken(newAccess);
        resp.setRefreshToken(newRefresh);
        resp.setTokenType("Bearer");
        resp.setExpiresIn(jwtService.getAccessTokenTtlSeconds());
        resp.setUser(toResponse(user));

        return ResponseEntity.ok(resp);
    }

    private UserResponse toResponse(User u) {
        UserResponse r = new UserResponse();
        if (u.getUserId() != null) r.setUserId(u.getUserId().intValue());
        r.setName(u.getName());
        r.setRole(u.getRole());
        r.setEmail(u.getEmail());
        r.setPhone(u.getPhone());
        r.setStatus(u.isStatus());
        return r;
    }
}