package com.agrigov.controller;

import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import com.agrigov.dto.FarmerDocumentRequest;
import com.agrigov.dto.FarmerDocumentResponse;
import com.agrigov.service.FarmerDocumentService;

import lombok.extern.slf4j.Slf4j;

@RestController
@RequestMapping("/documents")
@Slf4j
public class FarmerDocumentController {

    @Autowired
    private FarmerDocumentService service;

    @PostMapping("/upload")
    public FarmerDocumentResponse uploadDocument(@RequestParam("farmerId") Long farmerId,
                                                 @RequestParam("docType") String docType,
                                                 @RequestParam("file") MultipartFile file) {
        log.info("Uploading document for farmer ID: {}", farmerId);
        return service.uploadDocument(farmerId, docType, file);
    }

    @PutMapping("/update/{id}") //use document id for updation
    public FarmerDocumentResponse updateDocument(@PathVariable("id") Long documentId,
                                                     @RequestParam(value = "docType", required = false) String docType,
                                                     @RequestParam(value = "file", required = false) MultipartFile file) {
        log.info("Updating document ID {} with new file", documentId);
        return service.updateDocument(documentId, docType, file);
    }

    @DeleteMapping("/delete/{id}")
    public String deleteDocument(@PathVariable("id") Long documentId) {
        log.warn("Deleting document ID: {}", documentId);
        service.deleteDocument(documentId);
        return "Document with ID " + documentId + " deleted successfully";
    }

    @GetMapping("/fetch/{id}")
    public FarmerDocumentResponse getDocumentById(@PathVariable("id") Long documentId) {
        log.debug("Fetching document by ID: {}", documentId);
        return service.getDocumentById(documentId);
    }

    @GetMapping("/fetchByFarmer/{farmerId}")
    public List<FarmerDocumentResponse> getDocumentsByFarmer(@PathVariable("farmerId") Long farmerId) {
        log.info("Fetching documents for farmer ID: {}", farmerId);
        return service.getDocumentsByFarmer(farmerId);
    }

    @GetMapping("/fetchByStatus/{status}")
    public List<FarmerDocumentResponse> getDocumentsByStatus(@PathVariable("status") String status) {
        log.info("Fetching documents with status: {}", status);
        return service.getDocumentsByStatus(status);
    }
}